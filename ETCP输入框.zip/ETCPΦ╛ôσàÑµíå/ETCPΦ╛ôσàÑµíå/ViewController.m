//
//  ViewController.m
//  ETCP输入框
//
//  Created by 亮亮 on 16/8/30.
//  Copyright © 2016年 亮亮. All rights reserved.
//

#import "ViewController.h"
#import "CLLTextView.h"

@interface ViewController ()

@property (nonatomic , strong)CLLTextView *textView1;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithWhite:0.95 alpha:1];
    [self.view addSubview:self.textView1];
}
- (CLLTextView *)textView1{
    if (_textView1 == nil) {
       _textView1 = [[CLLTextView alloc]initWithFrame:CGRectMake(0, 30, [UIScreen mainScreen].bounds.size.width, 50)];
       _textView1.controller = self;
       [_textView1 show];
       
        
    }
    return _textView1;
}
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
