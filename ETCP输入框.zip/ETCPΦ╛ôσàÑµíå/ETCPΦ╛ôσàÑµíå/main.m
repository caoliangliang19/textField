//
//  main.m
//  ETCP输入框
//
//  Created by 亮亮 on 16/8/30.
//  Copyright © 2016年 亮亮. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
